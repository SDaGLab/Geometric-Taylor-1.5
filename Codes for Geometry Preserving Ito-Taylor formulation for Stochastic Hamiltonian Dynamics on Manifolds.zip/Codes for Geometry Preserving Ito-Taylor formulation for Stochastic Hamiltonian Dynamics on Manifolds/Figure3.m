%  Figure 3: Comparison of the global error for the proposed scheme 
%  with existing geometric EM, geometric Milstein and geometric Taylor
%  1.5 scheme
% 
%    Stochastic free rigid body - A benchmark case study 
% 
% Author: Satyam Panda(1), Ankush Gogoi(2), Budhaditya Hazra(1), Vikram Pakrashi(2)
% (1) Indian Institute of Technology Guwahati, Assam, India
% (2) University College Dublin, Dublin, Ireland
%
% ***********************************************************************
clc
clear
close all
warning off
addpath('./m_functions/');

% Set up the parameters
syms x [3,1]; 
I1 = 2; I2 = 1; I3 = 2/3;
bS2f =  so3_wedge([x(1)/I1; x(2)/I2; x(3)/I3]);
aS2f = (tril(bS2f^2)-diag(diag(tril(bS2f^2))) + 0.5*diag(diag(bS2f^2)));

% Kolmogorov operator on S2
[L0_aS2, L0_bS2, L1_aS2, L1_bS2, L1L1_bS2] = tayL0L1_S2(aS2f,bS2f,x);

aS2_v = matlabFunction(aS2f,'vars',{( x)});
bS2_v = matlabFunction(bS2f,'vars',{( x)});
L0aS2_v = matlabFunction(L0_aS2,'vars',{( x)});
L1aS2_v = matlabFunction(L1_aS2,'vars',{( x)});
L0bS2_v = matlabFunction(L0_bS2,'vars',{( x)});
L1bS2_v = matlabFunction(L1_bS2,'vars',{( x)});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{( x)});

% sequence time (s)
NSIM = 1000;
T =20;

% Intensity of stochastic excitation
sigWS2 = 0.05; sigZS2 = 0.5;
tic
for i=1:6  % integration with 6 different time steps
%
i

    if(i==1); dt=2^-12; % Reference
    elseif(i==2); dt=2^-10;
    elseif(i==3); dt=2^-8;
    elseif(i==4); dt=2^-6;
    elseif(i==5); dt=2^-4;
    elseif(i==6); dt=2^-2;
    end
    deltamat = [sqrt(dt)            0;
          dt^1.5/2    dt^1.5/(2*sqrt(3))];
    freq = 1/dt;
    time = 0:dt:T-dt;
    N = T*freq;
for scheme = 1:3 %Scheme 1-gEM,2-gMilstein, 3-gTaylor 1.5

for nsim = 1:NSIM % Monte Carlo simulation
    nsim;
y = zeros(3,N);
y(:,1) = [sin(1.1);0;cos(1.1)]; % omega

% 

for n = 1:N
  n;
  rng(1,'philox');
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,3))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,3))'; 


% Morion of position vector of pendulum (S2)
    aS2 = aS2_v([y(:,n)]);
    bS2 = bS2_v([y(:,n)]);
    L0aS2 = L0aS2_v([y(:,n)]);
    L1aS2 = L1aS2_v([y(:,n)]);
    L0bS2 = L0bS2_v([y(:,n)]);
    L1bS2 = L1bS2_v([y(:,n)]);
    L1L1bS2 = L1L1bS2_v([y(:,n)]);

if scheme == 1           
    omeg =  aS2.*dt + bS2.*DWS2(1);

elseif scheme == 2
    omeg =  aS2.*dt + bS2.*DWS2(1) + L1bS2.*(DWS2(1).^2-dt)/2;

elseif scheme == 3
    omeg =  aS2.*dt + bS2.*DWS2(1)...
                  + L0aS2.*dt^2/2 + L1bS2.*(DWS2(1).^2-dt)/2 + L1aS2.*DZS2(1)...
                 + L0bS2.*(DWS2(1)*dt - DZS2(1))+ L1L1bS2.*((1/3)*DWS2(1) - dt).*DWS2(1);
end
    y(:,n+1) = so3_exp_new(omeg)*y(:,n);    

end
YY(:,nsim,:) = y;

clear y
end
% Taking Karchar's mean on S2
        if scheme == 1
            for jj = 1:N
            Y_GEM(:,jj) = karcher_mean_sphere(YY(:,:,jj));
            end
        elseif scheme == 2
            for jj = 1:N
            Y_Gmil(:,jj) = karcher_mean_sphere(YY(:,:,jj));
            end
        elseif scheme == 3
            for jj = 1:N
            Y_GTay(:,jj) = karcher_mean_sphere(YY(:,:,jj));
            end
        end
clear YY
end
    muEM(:,i) = max(Y_GEM')';
    mumil(:,i) = max(Y_Gmil')';
    muTay(:,i) = max(Y_GTay')';

    errEM(:,i) = log2(norm(muEM(:,i) - muEM(:,1)));
    errmil(:,i) = log2(norm(mumil(:,i) - muEM(:,1)));
    errTay(:,i) = log2(norm(muTay(:,i) - muEM(:,1)));
    xdt(i)=log2(dt);  % logarithm of time step wrt the base '2'
clear Y_GEM Y_GTay Y_Gmil
end
toc

% Plotting results
figure; sgplot('Figure 3')
    plot(xdt(3:end),errEM(3:end),'-or','linewidth',2); hold on; 
    plot(xdt(3:end),errmil(3:end),'-ob','linewidth',2); hold on; 
    plot(xdt(3:end),errTay(3:end),'-ok','linewidth',2);
legend('gEM','gMilstein','gTay')
ylabel('log_2(||E[q_{ref}] - E[q]||)'); xlabel('log_2(\Deltat)')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')