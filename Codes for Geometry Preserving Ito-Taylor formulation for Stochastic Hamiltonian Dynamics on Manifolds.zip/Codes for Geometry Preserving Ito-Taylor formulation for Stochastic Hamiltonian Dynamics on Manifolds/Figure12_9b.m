%  Figure 9(b) and 12: Trajectory and geometric constraints of 
%                      Quadrotors transporting a point mass
% 
%            Quadrotors transporting a point mass on R3 x (S2 x SO3)^2
% 
% Author: Satyam Panda(1), Ankush Gogoi(2), Budhaditya Hazra(1), Vikram Pakrashi(2)
% (1) Indian Institute of Technology Guwahati, Assam, India
% (2) University College Dublin, Dublin, Ireland
%
% ***********************************************************************
clc
clear
close all
warning off
addpath('./m_functions/');

%  Setting up the parameters
syms xi [30,1]; 
L1 = 0.9; L2 = 0.8;
my = 1; m1 = 0.755; m2 = 0.755;
g = 9.81;
e3 = [0;0;1];
J1 = diag([0.0820,0.0845,0.1377]); J2 = diag([0.0820,0.0845,0.1377]);

x = xi(1:3); % 3x1 mass point disp
v = xi(4:6); % 3x1 mass point velocity
q1 = xi(7:9); % 3x1 Rotor-1 position in S2
q2 = xi(10:12); % 3x1 Rotor-2 position in S2
R1 = xi(13:15); % 3x1 Rotor-1 rotation in SO3
R2 = xi(16:18); % 3x1 Rotor-2 rotation in SO3
om1 = xi(19:21); % 3x1 Rotor-1 angular frequency in TS2
om2 = xi(22:24); % 3x1 Rotor-2 angular frequency in TS2
OM1 = xi(25:27); % 3x1 Rotor-1 angular frequency in TSO3
OM2 = xi(28:30); % 3x1 Rotor-2 angular frequency in TSO3

% Setting up the equation of motion
u1 = so3_from_rpy(R1)*e3; u2 = so3_from_rpy(R2)*e3; M1 = cross(OM1,J1*OM1); M2 = cross(OM2,J2*OM2);

Mq = my*eye(3) + m1*(q1*q1.') + m2*(q2*q2.');
Mat1 = [eye(3) zeros(3,15);
zeros(3,3) Mq zeros(3,12);
zeros(3,6) J1 zeros(3,9);
zeros(3,9) J2 zeros(3,6);
zeros(3,3) (-1/L1)*so3_wedge(q1) zeros(3,6) eye(3) zeros(3,3);
zeros(3,3) (-1/L2)*so3_wedge(q2) zeros(3,9) eye(3)];

Mat2 = [v;
        -m1*L1*(om1).^2.*q1-m2*L2*(om2).^2.*q2+Mq*g*e3+q1*q1.'*u1+q2*q2.'*u2;
        -cross(OM1,J1*OM1) + M1;
        -cross(OM1,J1*OM1) + M1;
        (-1/L1)*g*so3_wedge(q1)*e3 - (-1/(m1*L1))*cross(q1,(eye(3) - q1*q1.')*u1);
        (-1/L2)*g*so3_wedge(q2)*e3 - (-1/(m2*L2))*cross(q2,(eye(3) - q2*q2.')*u2)];

a = -inv(Mat1)*Mat2;

dh_pi = [0; 0; 0];
dh_q = [0.5; 0.5; 0.5];

% Setting the state space
aEf = a(1:6); 
bEf = [0; 0; 0; 0.5; 0.5; 0.5];

aS2f = [so3_wedge(om1); so3_wedge(om2)];   
bS2f = zeros(size(aS2f));%

aSO3f = [so3_wedge(OM1); so3_wedge(OM2)];   
bSO3f = zeros(size(aSO3f));

aTSf = a(7:18);   
bTSf = [dh_q;dh_q;dh_q;dh_q];

% Finding Kolmogorov operators on R3
[L0_aE, L0_bE, L1_aE, L1_bE, L1L1_bE] = tayL0L1(aEf,bEf,xi(1:6));

% Finding Kolmogorov operators on S2
for i = 1:2
[L0_aS2(1+3*(i-1):3+3*(i-1),:), L0_bS2(1+3*(i-1):3+3*(i-1),:),...
    L1_aS2(1+3*(i-1):3+3*(i-1),:), L1_bS2(1+3*(i-1):3+3*(i-1),:),...
    L1L1_bS2(1+3*(i-1):3+3*(i-1),:)] = tayL0L1_S2(aS2f(1+3*(i-1):3+3*(i-1),:)...
    ,bS2f(1+3*(i-1):3+3*(i-1),:),xi(7+3*(i-1):9+3*(i-1),:));
end

% Finding Kolmogorov operators on SO3
for i = 1:2
[L0_aSO3(1+3*(i-1):3+3*(i-1),:), L0_bSO3(1+3*(i-1):3+3*(i-1),:),...
    L1_aSO3(1+3*(i-1):3+3*(i-1),:), L1_bSO3(1+3*(i-1):3+3*(i-1),:),...
    L1L1_bSO3(1+3*(i-1):3+3*(i-1),:)] = tayL0L1_S2(aSO3f(1+3*(i-1):3+3*(i-1),:)...
    ,bSO3f(1+3*(i-1):3+3*(i-1),:),xi(13+3*(i-1):15+3*(i-1),:));
end

% Finding Kolmogorov operators on Tangent spaces
[L0_aTS, L0_bTS, L1_aTS, L1_bTS, L1L1_bTS] = tayL0L1_TS(aTSf,bTSf,[xi(19:30)]);


aE_v = matlabFunction(aEf,'vars',{([xi])});
L0aE_v = matlabFunction(L0_aE,'vars',{([xi])});
L1aE_v = matlabFunction(L1_aE,'vars',{([xi])});
L0bE_v = matlabFunction(L0_bE,'vars',{([xi])});
L1bE_v = matlabFunction(L1_bE,'vars',{([xi])});
L1L1bE_v = matlabFunction(L1L1_bE,'vars',{([xi])});

aS2_v = matlabFunction(aS2f,'vars',{([xi])});
L0aS2_v = matlabFunction(L0_aS2,'vars',{([xi])});
L1aS2_v = matlabFunction(L1_aS2,'vars',{([xi])});
L0bS2_v = matlabFunction(L0_bS2,'vars',{([xi])});
L1bS2_v = matlabFunction(L1_bS2,'vars',{([xi])});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{([xi])});

aSO3_v = matlabFunction(aSO3f,'vars',{([xi])});
L0aSO3_v = matlabFunction(L0_aSO3,'vars',{([xi])});
L1aSO3_v = matlabFunction(L1_aSO3,'vars',{([xi])});
L0bSO3_v = matlabFunction(L0_bSO3,'vars',{([xi])});
L1bSO3_v = matlabFunction(L1_bSO3,'vars',{([xi])});
L1L1bSO3_v = matlabFunction(L1L1_bSO3,'vars',{([xi])});

aTS_v = matlabFunction(aTSf,'vars',{([xi])});
L0aTS_v = matlabFunction(L0_aTS,'vars',{([xi])});
L1aTS_v = matlabFunction(L1_aTS,'vars',{([xi])});
L0bTS_v = matlabFunction(L0_bTS,'vars',{([xi])});
L1bTS_v = matlabFunction(L1_bTS,'vars',{([xi])});
L1L1bTS_v = matlabFunction(L1L1_bTS,'vars',{([xi])});

%% Parameters
% sequence time (s)
T = 20;

% Intensities of stochastic excitations
% For figure 11(a) set Intensity of stochastic excitation to zero
% That will provide a deterministic solution
sigWE = 0.03; sigZE = 0.030;
sigWS2 = 0.2; sigZS2 = 0.2;
sigWSO3 = 0; sigZSO3 = 0;
sigWTS = 0.1; sigZTS = 0.1;
dt = 0.01;

deltamat = [sqrt(dt)            0;
      dt^1.5/2    dt^1.5/(2*sqrt(3))];
freq = 1/dt;
time = 0:dt:T-dt;
N = T*freq;

y = zeros(30,N);

% Initial conditions
y(:,1) = [1;0;0; % x
          0;0;0; % xdot
          sin(30);0;cos(30);  % q1
          0;sin(30);cos(30);  % q2
          0;0;0; % R1
          0;0;0; % R2
         0.05;0.02;0.05; 
         0.05;0.02;0.05;
         0.0;0.0;0.0;
         0.0;0.0;0.0]; % omega

for n = 1:N % Time integration with geometric Taylor 1.5 scheme
  n

    DWE = sigWE*(deltamat(1,:)*randn(2,6))'; 
    DZE = sigZE*(deltamat(2,:)*randn(2,6))'; 
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,6))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,6))'; 
    DWSO3 = sigWSO3*(deltamat(1,:)*randn(2,6))'; 
    DZSO3 = sigZSO3*(deltamat(2,:)*randn(2,6))'; 
    DWTS = sigWTS*(deltamat(1,:)*randn(2,12))'; 
    DZTS = sigZTS*(deltamat(2,:)*randn(2,12))'; 

% Motion of mass particle (R3)
    aE = aE_v([y(:,n)]);
    bE = bEf;
    L0aE = L0aE_v([y(:,n)]);
    L1aE = L1aE_v([y(:,n)]);
    L0bE = L0bE_v([y(:,n)]);
    L1bE = L1bE_v([y(:,n)]);
    L1L1bE = L1L1bE_v([y(:,n)]);

    y(1:6,n+1) = y(1:6,n) + aE.*dt + bE.*DWE...
                      + L0aE.*dt^2/2 + L1bE.*(DWE.^2-dt)/2 + L1aE.*DZE...
                      + L0bE.*(DWE*dt - DZE) + L1L1bE.*((1/3)*DWE - dt).*DWE;

% Position vector of quadrotors (S2)
vars = [y(1:6,n);y(7:end,n)];
    aS2 = aS2_v( vars);
    bS2 = bS2f;
    L0aS2 = L0aS2_v( vars);
    L1aS2 = L1aS2_v( vars);
    L0bS2 = L0bS2_v( vars);
    L1bS2 = L1bS2_v( vars);
    L1L1bS2 = L1L1bS2_v( vars);

    omeg =  aS2.*dt + bS2.*DWS2...
                  + L0aS2.*dt^2/2 + L1bS2.*(DWS2.^2-dt)/2 + L1aS2.*DZS2...
                  + L0bS2.*(DWS2*dt - DZS2) + L1L1bS2.*((1/3)*DWS2 - dt).*DWS2;
    y(7:9,n+1) = so3_exp(so3_vee(omeg(1:3,:)))*y(7:9,n);    
    y(10:12,n+1) = so3_exp(so3_vee(omeg(4:6,:)))*y(10:12,n);    

% Rotation matrix of quadrotors (SO3)
    vars = [y(1:12,n);y(13:end,n)];
    aSO3 = aSO3_v( vars);
    bSO3 = bSO3f;
    L0aSO3 = L0aSO3_v( vars);
    L1aSO3 = L1aSO3_v( vars);
    L0bSO3 = L0bSO3_v( vars);
    L1bSO3 = L1bSO3_v( vars);
    L1L1bSO3 = L1L1bSO3_v( vars);

    OMEG =  aSO3.*dt + bSO3.*DWSO3...
                  + L0aSO3.*dt^2/2 + L1bSO3.*(DWSO3.^2-dt)/2 + L1aSO3.*DZSO3...
                  + L0bSO3.*(DWSO3*dt - DZSO3) + L1L1bSO3.*((1/3)*DWSO3 - dt).*DWSO3;
    R11 = so3_from_rpy(y(13:15,n))*so3_exp(so3_vee(OMEG(1:3,:)));    
    y(13:15,n+1) = so3_to_rpy(R11);
    R12 = so3_from_rpy(y(16:18,n))*so3_exp(so3_vee(OMEG(4:6,:)));    
    y(16:18,n+1) = so3_to_rpy(R12);

% Angular momentum (TS)
    vars = [y(1:18,n);y(19:end,n)];
    aTS = aTS_v( vars);
    bTS = bTSf;
    L0aTS = L0aTS_v( vars);
    L1aTS = L1aTS_v( vars);
    L0bTS = L0bTS_v( vars);
    L1bTS = L1bTS_v( vars);
    L1L1bTS = L1L1bTS_v( vars);

    omg_upd = y(19:30,n) + aTS.*dt + bTS.*DWTS...
                      + L0aTS.*dt^2/2 + L1bTS.*(DWTS.^2-dt)/2 + L1aTS.*DZTS...
                      + L0bTS.*(DWTS*dt - DZTS) + L1L1bTS.*((1/3)*DWTS - dt).*DWTS;
    y(19:21,n+1) = ParTransport(y(7:9,n),y(7:9,n+1))*omg_upd(1:3);
    y(22:24,n+1) = ParTransport(y(10:12,n),y(10:12,n+1))*omg_upd(4:6);
    y(25:27,n+1) = ParTransport(y(13:15,n),y(13:15,n+1))*omg_upd(7:9);
    y(28:30,n+1) = ParTransport(y(16:18,n),y(16:18,n+1))*omg_upd(10:12);

end

% storing variables
yC = y(1:3,:);
Q_r1 = y(7:9,:);
Q_r2 = y(10:12,:);
om1 = y(19:21,:);
om2 = y(22:24,:);
yr1 = yC - L1*Q_r1;
yr2 = yC - L2*Q_r2;

% Plotting Figure 9(b)
figure;sgtitle('Figure 9(b)')
subplot(1,2,2);plot(abs(dot(Q_r1,om1)),'linewidth',2); xlim([100 2000])
ylabel('${q} \cdot \omega$', 'Interpreter','latex','fontname','times','fontsize',22,'fontweight','bold')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')
subplot(1,2,1);plot(abs(dot(Q_r1,Q_r1)-1),'linewidth',2); xlim([100 2000])
ylabel('$q \cdot q-1$', 'Interpreter','latex','fontname','times','fontsize',22,'fontweight','bold')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')

% Plotting Figure 12(b)
figure, sgtitle('Figure 12(b)')
plot3(yC(1,:),yC(2,:),yC(3,:),'r','linewidth',2); hold on
plot3([yC(1,1);yr1(1,1)],[yC(2,1);yr1(2,1)],[yC(3,1);yr1(3,1)],'-ok','linewidth',2); hold on
plot3([yC(1,1);yr2(1,1)],[yC(2,1);yr2(2,1)],[yC(3,1);yr2(3,1)],'-ok','linewidth',2); hold on
plot3([yC(1,500);yr1(1,500)],[yC(2,500);yr1(2,500)],[yC(3,500);yr1(3,500)],'-ok','linewidth',2); hold on
plot3([yC(1,500);yr2(1,500)],[yC(2,500);yr2(2,500)],[yC(3,500);yr2(3,500)],'-ok','linewidth',2); hold on
plot3([yC(1,1000);yr1(1,1000)],[yC(2,1000);yr1(2,1000)],[yC(3,1000);yr1(3,1000)],'-ok','linewidth',2); hold on
plot3([yC(1,1000);yr2(1,1000)],[yC(2,1000);yr2(2,1000)],[yC(3,1000);yr2(3,1000)],'-ok','linewidth',2); hold on
plot3([yC(1,1500);yr1(1,1500)],[yC(2,1500);yr1(2,1500)],[yC(3,1500);yr1(3,1500)],'-ok','linewidth',2); hold on
plot3([yC(1,1500);yr2(1,1500)],[yC(2,1500);yr2(2,1500)],[yC(3,1500);yr2(3,1500)],'-ok','linewidth',2); hold on
plot3([yC(1,2000);yr1(1,2000)],[yC(2,2000);yr1(2,2000)],[yC(3,2000);yr1(3,2000)],'-ok','linewidth',2); hold on
plot3([yC(1,2000);yr2(1,2000)],[yC(2,2000);yr2(2,2000)],[yC(3,2000);yr2(3,2000)],'-ok','linewidth',2); hold on
view(128.5,29); grid on
xlabel('X Position'); ylabel('Y Position'); zlabel('Z Position');
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')

% For figure 11(a) set Intensity of stochastic excitation to zero
% That will provide a deterministic solution