%  Figure 10(a): Measure of geometry preservation through the response 
%                trajectory of Kuramoto oscillator
% 
%            Stochastic Kuramoto Oscillator on S2
% 
% Author: Satyam Panda(1), Ankush Gogoi(2), Budhaditya Hazra(1), Vikram Pakrashi(2)
% (1) Indian Institute of Technology Guwahati, Assam, India
% (2) University College Dublin, Dublin, Ireland
%
% ***********************************************************************
clc
clear
close all
warning off
addpath('./m_functions/');

%%------------------------Geometric Taylor 1.5 scheme -----------------%%
% Setting up the differential equation
syms x [3,1]; 
A = so3_wedge(ones(3,1));
bS2f =  so3_wedge(cross([2.5;0.5;1.9],x));
aS2f = (so3_wedge([0.5 0.8 0.3]) + (1-x.'*x)*A - so3_wedge(cross(A*x,x)));

% Make kolmogorov operators on S2
[L0_aS2, L0_bS2, L1_aS2, L1_bS2, L1L1_bS2] = tayL0L1_S2(aS2f,bS2f,x);

aS2_v = matlabFunction(aS2f,'vars',{(x)});
bS2_v = matlabFunction(bS2f,'vars',{(x)});
L0aS2_v = matlabFunction(L0_aS2,'vars',{(x)});
L1aS2_v = matlabFunction(L1_aS2,'vars',{(x)});
L0bS2_v = matlabFunction(L0_bS2,'vars',{(x)});
L1bS2_v = matlabFunction(L1_bS2,'vars',{(x)});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{(x)});

% sequence time (s)
NSIM = 10;
T =5;

% Intensity of the stochastic excitation
sigWS2 = 0.1; sigZS2 = 0.09;
dt = 0.01;
    deltamat = [sqrt(dt)            0;
          dt^1.5/2    dt^1.5/(2*sqrt(3))];
    freq = 1/dt;
    time = 0:dt:T-dt;
    N = T*freq;
for nsim = 1:NSIM
    nsim
y = zeros(3,N);
y(:,1) = [0;0;1]; % omega

% 

for n = 1:N
  n;
  rng(1,'philox');
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,3))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,3))'; 


% Morion of position vector of pendulum (S2)
    aS2 = aS2_v([y(:,n)]);
    bS2 = bS2_v([y(:,n)]);
    L0aS2 = L0aS2_v([y(:,n)]);
    L1aS2 = L1aS2_v([y(:,n)]);
    L0bS2 = L0bS2_v([y(:,n)]);
    L1bS2 = L1bS2_v([y(:,n)]);
    L1L1bS2 = L1L1bS2_v([y(:,n)]);


    omeg =  aS2.*dt + bS2.*DWS2(1)...
                  + L0aS2.*dt^2/2 + L1bS2.*(DWS2(1).^2-dt)/2 + L1aS2.*DZS2(1)...
                 + L0bS2.*(DWS2(1)*dt - DZS2(1))+ L1L1bS2.*((1/3)*DWS2(1)- dt).*DWS2(1);;
    y(:,n+1) = so3_exp_new(omeg)*y(:,n);    

end
YY(:,nsim,:) = y;

clear y
end
for jj = 1:N
     Y_GTay(:,jj) = karcher_mean_sphere(YY(:,:,jj));
end

clearvars -EXCEPT Y_GTay

%% 
syms x [3,1]; 

A = so3_wedge(ones(3,1));
bS2f =  so3_wedge(cross([2.5;0.5;0.9],x))*x;
aS2f = (so3_wedge([0.5 0.8 0.3]) + (1-x.'*x)*A - so3_wedge(cross(A*x,x)))*x;

[L0_aS2, L0_bS2, L1_aS2, L1_bS2, L1L1_bS2] = tayL0L1(aS2f,bS2f,x);

aS2_v = matlabFunction(aS2f,'vars',{(x)});
bS2_v = matlabFunction(bS2f,'vars',{(x)});
L0aS2_v = matlabFunction(L0_aS2,'vars',{(x)});
L1aS2_v = matlabFunction(L1_aS2,'vars',{(x)});
L0bS2_v = matlabFunction(L0_bS2,'vars',{(x)});
L1bS2_v = matlabFunction(L1_bS2,'vars',{(x)});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{(x)});

%%------------------------Non-geometric EM scheme -----------------------%%
% sequence time (s)
NSIM = 10;
T =5;
sigWS2 = 0.1; sigZS2 = 0.09;
dt = 0.01;
    deltamat = [sqrt(dt)            0;
          dt^1.5/2    dt^1.5/(2*sqrt(3))];
    freq = 1/dt;
    time = 0:dt:T-dt;
    N = T*freq;
for nsim = 1:NSIM
    nsim
y = zeros(3,N);
y(:,1) = [0;0;1]; % omega

% 

for n = 1:N
  n;
  rng(1,'philox');
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,3))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,3))'; 


% Morion of position vector of pendulum (S2)
    aS2 = aS2_v([y(:,n)]);
    bS2 = bS2_v([y(:,n)]);
    L0aS2 = L0aS2_v([y(:,n)]);
    L1aS2 = L1aS2_v([y(:,n)]);
    L0bS2 = L0bS2_v([y(:,n)]);
    L1bS2 = L1bS2_v([y(:,n)]);
    L1L1bS2 = L1L1bS2_v([y(:,n)]);


    y(:,n+1) =  y(:,n) + aS2.*dt + bS2.*DWS2(1);
end
YY(:,:,nsim) = y;

clear y
end
            Y_EM = mean(YY,3);
clearvars -EXCEPT Y_GTay Y_EM

% Plotting figure 7
L = 1;
[X1,Y1,Z1] = sphere(25);
X2 = X1 * L;
Y2 = Y1 * L;
Z2 = Z1 * L;
%
figure, sgplot('Figure 7')
FIG = surf(X2,Y2,Z2);
set(FIG, 'FaceAlpha', 0.5,'EdgeAlpha', 0.2)
shading interp
axis equal; hold on
plot3(Y_EM(1,:),Y_EM(2,:),Y_EM(3,:),'r','linewidth',2); hold on
plot3(Y_GTay(1,:),Y_GTay(2,:),Y_GTay(3,:),'b','linewidth',2);
xlabel('X Position'); ylabel('Y Position'); zlabel('Z Position')
legend('S^2','EM','g-Taylor 1.5')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')
