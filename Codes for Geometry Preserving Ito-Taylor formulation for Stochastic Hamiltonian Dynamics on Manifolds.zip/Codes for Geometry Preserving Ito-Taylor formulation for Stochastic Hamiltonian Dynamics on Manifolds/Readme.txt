The code is a part of the manuscript titled:
```````````````````````````````````````````````````````````````````````````
Geometry Preserving Ito-Taylor formulation for Stochastic Hamiltonian Dynamics on Manifolds

```````````````````````````````````````````````````````````````````````````

Journal: Applied Mathematical Modelling, Elsevier.

Authors: Satyam Pamda, Ankush Gogoi, Budhaditya Hazra, Vikram Pakrashi

Note:
i. For clear understanding about the codes please refer the theory present in the paper.
ii. For any further query contact the authors.
(The contact address is present in the paper).


Copyright: The codes are subjected to use provided due citation is given to the paper appropriately.