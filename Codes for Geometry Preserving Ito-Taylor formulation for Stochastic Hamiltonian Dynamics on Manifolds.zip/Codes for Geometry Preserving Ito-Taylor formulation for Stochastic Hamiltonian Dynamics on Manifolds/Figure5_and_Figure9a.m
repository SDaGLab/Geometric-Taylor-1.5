%  Figure 5 and 9 (a): Trajectory of the cart in R2 and pendulum in S2
% 
%            Stochastic Pendulum Cart on (S2 x R2)
% 
% Author: Satyam Panda(1), Ankush Gogoi(2), Budhaditya Hazra(1), Vikram Pakrashi(2)
% (1) Indian Institute of Technology Guwahati, Assam, India
% (2) University College Dublin, Dublin, Ireland
%
% ***********************************************************************
clc
clear
close all
warning off
addpath('./m_functions/');

% Setting up the parameters
syms xi [10,1]
M = 15;
m = 0.09*M; 
L = 1; 
k = 50; 
c = 5;
g = 9.81;
e3 = [0;0;1]; C = [1 0; 0 1; 0 0];
x = xi(1:2); % 2x1 cart disp
p = xi(3:4); % 2x1 cart conjugate velocity
q = xi(5:7); % 3x1 pendulum position wrt cart
pii = xi(8:10); % 3x1 conjugate angular frequency

% Setting up the Lagrangian and Hamiltonian
syms xd [2,1]
syms om [3,1]
Lag = 0.5*(M+m)*xd.'*xd - m*L*xd.'*C'*so3_wedge(q)*om + 0.5*m*L^2*om.'*om - m*g*L*e3'*q -0.5*k*x.'*x;
temp = 1;
for i = 1:2
    EQN(temp) = xd(i) == solve(diff(Lag,xd(i)) == p(i), xd(i));
    temp = temp+1;
end
for i = 1:3
    EQN(temp) = om(i) == solve(diff(Lag,om(i)) == pii(i), om(i));
    temp = temp+1;
end
SS = solve(EQN,[xd;om]);
xdf(1) = SS.xd1;
xdf(2) = SS.xd2;
omf(1) = SS.om1;
omf(2) = SS.om2;
omf(3) = SS.om3;
L_new = subs(Lag,[xd;om],[xdf.';omf.']);
H = p.'*xdf.' + pii.'*omf.' - L_new;
omf_v = matlabFunction(omf,'vars',{([xi])});
v_v = matlabFunction(xdf,'vars',{([xi])});

% Finding out the state space and Kolmogorov operators
dH_x = simplify([diff(H,xi(1));diff(H,xi(2))] + c*xdf.');
dH_p = simplify([diff(H,xi(3));diff(H,xi(4))]);
dH_q = simplify([diff(H,xi(5));diff(H,xi(6)); diff(H,xi(7))]);
dH_pi = simplify([diff(H,xi(8));diff(H,xi(9)); diff(H,xi(10))]);

dh_pi = [0; 0; 0];
dh_q = [0.5; 0.2; 0.3];

% States on S2
aS2f = [so3_wedge(dH_pi)];   
bS2f = so3_wedge(dh_pi);

% States on TqS2
aTSf = so3_wedge(-cross(q,dH_q) + cross(dH_pi,pii));   
bTSf = so3_wedge(-cross(q,dh_q) + cross(dh_pi,pii));
aTSf = aTSf + so3_wedge(so3_wedge(dh_q)*so3_wedge(dh_pi)*q + 0.5*so3_wedge(dh_pi)^2*pii);

% States on R2
aEf = [dH_p;-dH_x]; 
bEf = [0; 0; 0.5; 0.5];

% Kolmogorov operators on R2
[L0_aE, L0_bE, L1_aE, L1_bE, L1L1_bE] = tayL0L1(aEf,bEf,xi(1:4));
% Kolmogorov operators on S2
[L0_aS2, L0_bS2, L1_aS2, L1_bS2, L1L1_bS2] = tayL0L1_S2(aS2f,bS2f,xi(5:7));
% Kolmogorov operators on TqS2
[L0_aTS, L0_bTS, L1_aTS, L1_bTS, L1L1_bTS] = tayL0L1_TS(aTSf,bTSf,xi(8:10));

aE_v = matlabFunction(aEf,'vars',{([xi])});
L0aE_v = matlabFunction(L0_aE,'vars',{([xi])});
L1aE_v = matlabFunction(L1_aE,'vars',{(xi)});
L0bE_v = matlabFunction(L0_bE,'vars',{(xi)});
L1bE_v = matlabFunction(L1_bE,'vars',{([xi])});
L1L1bE_v = matlabFunction(L1L1_bE,'vars',{([xi])});

aTS_v = matlabFunction(aTSf,'vars',{([xi])});
bTS_v = matlabFunction(bTSf,'vars',{([xi])});
L0aTS_v = matlabFunction(L0_aTS,'vars',{([xi])});
L1aTS_v = matlabFunction(L1_aTS,'vars',{([xi])});
L0bTS_v = matlabFunction(L0_bTS,'vars',{([xi])});
L1bTS_v = matlabFunction(L1_bTS,'vars',{([xi])});
L1L1bTS_v = matlabFunction(L1L1_bTS,'vars',{([xi])});

aS2_v = matlabFunction(aS2f,'vars',{([xi])});
L0aS2_v = matlabFunction(L0_aS2,'vars',{([xi])});
L1aS2_v = matlabFunction(L1_aS2,'vars',{([xi])});
L0bS2_v = matlabFunction(L0_bS2,'vars',{([xi])});
L1bS2_v = matlabFunction(L1_bS2,'vars',{([xi])});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{([xi])});

% sequence time (s)
T = 50;
NSIM = 1;

sigWE = 0.3; sigZE = 0.3;
sigWS2 = 0.05; sigZS2 = 0.05;
sigWTS = 0.3; sigZTS = 0.3;
dt = 0.01;
deltamat = [sqrt(dt)            0;
      dt^1.5/2    dt^1.5/(2*sqrt(3))];
freq = 1/dt;
time = 0:dt:T-dt;
N = T*freq;

for nsim = 1:NSIM
nsim
y = zeros(10,N);

y(:,1) = [0;0; % x
          0.5;-1; % xdot
        1/sqrt(3);1/sqrt(3);-1/sqrt(3); % q
        0.1;0.2;0.3]; % omega

for n = 1:N
  n;
    DWE = sigWE*(deltamat(1,:)*randn(2,4))'; 
    DZE = sigZE*(deltamat(2,:)*randn(2,4))'; 
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,3))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,3))'; 
    DWTS = sigWTS*(deltamat(1,:)*randn(2,1))'; 
    DZTS = sigZTS*(deltamat(2,:)*randn(2,1))'; 

% Motion of cart (Euclidean)
    aE = aE_v([y(:,n)]);
    bE = bEf;
    L0aE = L0aE_v([y(:,n)]);
    L1aE = L1aE_v([y(:,n)]);
    L0bE = L0bE_v([y(:,n)]);
    L1bE = L1bE_v([y(:,n)]);
    L1L1bE = L1L1bE_v([y(:,n)]);

    y(1:4,n+1) = y(1:4,n) + aE.*dt + bE.*DWE...
                      + L0aE.*dt^2/2 + L1bE.*(DWE.^2-dt)/2 + L1aE.*DZE...
                      + L0bE.*(DWE*dt - DZE) + L1L1bE.*((1/3)*DWE - dt).*DWE;

% Position vector of pendulum (S2)
vars = [y(1:4,n+1);y(5:end,n)];
    aS2 = aS2_v(vars);
    bS2 = bS2f;
    L0aS2 = L0aS2_v([vars]);
    L1aS2 = L1aS2_v([vars]);
    L0bS2 = L0bS2_v([vars]);
    L1bS2 = L1bS2_v([vars]);
    L1L1bS2 = L1L1bS2_v([vars]);

    OMEG =  aS2.*dt + bS2.*DWS2...
            + L0aS2.*dt^2/2 + L1bS2.*(DWS2.^2-dt)/2 + L1aS2.*DZS2...
            + L0bS2.*(DWS2*dt - DZS2) + L1L1bS2.*((1/3)*DWS2 - dt).*DWS2;
    y(5:7,n+1) = so3_exp_new(OMEG)*y(5:7,n);   

% Angular momentum of pendulum (TS2)
vars = [y(1:7,n+1);y(8:end,n)];
    aTS = aTS_v([vars]);
    bTS = bTS_v([vars]);
    L0aTS = L0aTS_v([vars]);
    L1aTS = L1aTS_v([vars]);
    L0bTS = L0bTS_v([vars]);
    L1bTS = L1bTS_v([vars]);
    L1L1bTS = L1L1bTS_v([vars]);

    omg_upd = y(8:10,n) + so3_vee(aTS.*dt + bTS.*DWTS...
              + L0aTS.*dt^2/2 + L1bTS.*(DWTS.^2-dt)/2 + L1aTS.*DZTS...
              + L0bTS.*(DWTS*dt - DZTS) + L1L1bTS.*((1/3)*DWTS - dt).*DWTS);
    y(8:10,n+1) = ParTransport(y(1:3,n),y(1:3,n+1))*omg_upd;

% Angular velocity of pendulum (TS2)
    omfv(:,n+1) = omf_v(y(:,n+1)); % OMEGA
end
% Storing variables
YYc(:,:,nsim) = y(1:2,:);
YYp(:,nsim,:) = y(5:7,:);
PIp(:,:,nsim) = y(8:10,:);
OMp(:,:,nsim) = omfv;
clear y
end

for jj = 1:N
    Yp_GTay(:,jj) = karcher_mean_sphere(YYp(:,:,jj));
end
Yc_GTay = nanmean(YYc,3);
PI_GTay = nanmean(PIp,3);
OM_GTay = nanmean(OMp,3);

yC =Yc_GTay(:,1:end-1);
Q_r =Yp_GTay;
OM = OM_GTay(:,1:end-1);
yP = C*yC + L*Q_r;

%% Plotting
figure, sgtitle('Figure 5')
for i = 501:50:length(time)
    i;
plot3(yP(1,1:i),yP(2,1:i),yP(3,1:i),'k','linewidth',2); hold on
view(128.5,29); grid on
plot(yC(1,1:i),yC(2,1:i),'r','linewidth',2); 
plot3([yC(1,i);yP(1,i)],[yC(2,i);yP(2,i)],[0;yP(3,i)],'linewidth',2)
[xx yy] = meshgrid(-1.5:0.1:1.5); % Generate x and y data
zz = zeros(size(xx, 1)); % Generate z data
FIG = surf(xx, yy, zz); % Plot the surface
set(FIG, 'FaceAlpha', 0.5,'EdgeAlpha', 0.2)
xlim([-1.5 1.5]); ylim([-1.6 1.6]); zlim([-1.5 1.5]);
drawnow
hold off
end
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')

%% 
figure; sgtitle('Figure 9(a)')
subplot(1,2,1);plot(dot(Q_r,OM)-dot(Q_r(:,1),OM(:,1)),'linewidth',2); xlim([100 5000])
ylabel('${q} \cdot \omega$', 'Interpreter','latex','fontname','times','fontsize',24,'fontweight','bold')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')
subplot(1,2,2);plot(abs(dot(Q_r,Q_r)-1),'linewidth',2); xlim([100 5000])
ylabel('$q \cdot q-1$', 'Interpreter','latex','fontname','times new roman','fontsize',24,'fontweight','bold')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')
