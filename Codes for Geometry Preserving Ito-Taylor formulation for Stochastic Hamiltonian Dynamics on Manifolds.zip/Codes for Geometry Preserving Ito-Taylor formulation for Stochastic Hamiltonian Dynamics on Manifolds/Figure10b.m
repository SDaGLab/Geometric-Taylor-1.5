%  Figure 10(a): Comparison of the global error for the proposed scheme 
%  with existing geometric EM, geometric Milstein and geometric Taylor
%  1.5 scheme
% 
%            Stochastic Pendulum cart on (S2 x R2)
% 
% Author: Satyam Panda(1), Ankush Gogoi(2), Budhaditya Hazra(1), Vikram Pakrashi(2)
% (1) Indian Institute of Technology Guwahati, Assam, India
% (2) University College Dublin, Dublin, Ireland
%
% ***********************************************************************
clc
clear
close all
warning off
addpath('./m_functions/');

% Setting up the parameters
syms xi [10,1]
M = 15;
m = 0.09*M; 
L = 1; 
k = 50; 
c = 5;
g = 9.81;
e3 = [0;0;1]; C = [1 0; 0 1; 0 0];
x = xi(1:2); % 2x1 cart disp
p = xi(3:4); % 2x1 cart conjugate velocity
q = xi(5:7); % 3x1 pendulum position wrt cart
pii = xi(8:10); % 3x1 conjugate angular frequency

% Setting up the Lagrangian and Hamiltonian
syms xd [2,1]
syms om [3,1]
Lag = 0.5*(M+m)*xd.'*xd - m*L*xd.'*C'*so3_wedge(q)*om + 0.5*m*L^2*om.'*om - m*g*L*e3'*q -0.5*k*x.'*x;
temp = 1;
for i = 1:2
    EQN(temp) = xd(i) == solve(diff(Lag,xd(i)) == p(i), xd(i));
    temp = temp+1;
end
for i = 1:3
    EQN(temp) = om(i) == solve(diff(Lag,om(i)) == pii(i), om(i));
    temp = temp+1;
end
SS = solve(EQN,[xd;om]);
xdf(1) = SS.xd1;
xdf(2) = SS.xd2;
omf(1) = SS.om1;
omf(2) = SS.om2;
omf(3) = SS.om3;

L_new = subs(Lag,[xd;om],[xdf.';omf.']);

H = p.'*xdf.' + pii.'*omf.' - L_new;

omf_v = matlabFunction(omf,'vars',{([xi])});
v_v = matlabFunction(xdf,'vars',{([xi])});

% Finding out the state space and Kolmogorov operators
dH_x = simplify([diff(H,xi(1));diff(H,xi(2))] + c*xdf.');
dH_p = simplify([diff(H,xi(3));diff(H,xi(4))]);
dH_q = simplify([diff(H,xi(5));diff(H,xi(6)); diff(H,xi(7))]);
dH_pi = simplify([diff(H,xi(8));diff(H,xi(9)); diff(H,xi(10))]);

dh_pi = [0; 0; 0];
dh_q = [0.5; 0.2; 0.3];

% States on S2
aS2f = [so3_wedge(dH_pi)];   
bS2f = so3_wedge(dh_pi);

% States on TqS2
aTSf = so3_wedge(-cross(q,dH_q) + cross(dH_pi,pii));   
bTSf = so3_wedge(-cross(q,dh_q) + cross(dh_pi,pii));
aTSf = aTSf + so3_wedge(so3_wedge(dh_q)*so3_wedge(dh_pi)*q + 0.5*so3_wedge(dh_pi)^2*pii);

% States on R2
aEf = [dH_p;-dH_x]; 
bEf = [0; 0; 1; 1];

% Kolmogorov operators on R2
[L0_aE, L0_bE, L1_aE, L1_bE, L1L1_bE] = tayL0L1(aEf,bEf,xi(1:4));
% Kolmogorov operators on S2
[L0_aS2, L0_bS2, L1_aS2, L1_bS2, L1L1_bS2] = tayL0L1_S2(aS2f,bS2f,xi(5:7));
% Kolmogorov operators on TqS2
[L0_aTS, L0_bTS, L1_aTS, L1_bTS, L1L1_bTS] = tayL0L1_TS(aTSf,bTSf,xi(8:10));

aE_v = matlabFunction(aEf,'vars',{([xi])});
L0aE_v = matlabFunction(L0_aE,'vars',{([xi])});
L1aE_v = matlabFunction(L1_aE,'vars',{(xi)});
L0bE_v = matlabFunction(L0_bE,'vars',{(xi)});
L1bE_v = matlabFunction(L1_bE,'vars',{([xi])});
L1L1bE_v = matlabFunction(L1L1_bE,'vars',{([xi])});

aTS_v = matlabFunction(aTSf,'vars',{([xi])});
bTS_v = matlabFunction(bTSf,'vars',{([xi])});
L0aTS_v = matlabFunction(L0_aTS,'vars',{([xi])});
L1aTS_v = matlabFunction(L1_aTS,'vars',{([xi])});
L0bTS_v = matlabFunction(L0_bTS,'vars',{([xi])});
L1bTS_v = matlabFunction(L1_bTS,'vars',{([xi])});
L1L1bTS_v = matlabFunction(L1L1_bTS,'vars',{([xi])});

aS2_v = matlabFunction(aS2f,'vars',{([xi])});
L0aS2_v = matlabFunction(L0_aS2,'vars',{([xi])});
L1aS2_v = matlabFunction(L1_aS2,'vars',{([xi])});
L0bS2_v = matlabFunction(L0_bS2,'vars',{([xi])});
L1bS2_v = matlabFunction(L1_bS2,'vars',{([xi])});
L1L1bS2_v = matlabFunction(L1L1_bS2,'vars',{([xi])});

%% Parameters
% sequence time (s)
T = 10;
NSIM = 100;

sigWE = 0.05; sigZE = 0.05;
sigWS2 = 0.0; sigZS2 = 0.0;
sigWTS = 0.5; sigZTS = 0.5;

for i=1:6 % integration with 5 different time steps
%
i
    if(i==1); dt=2^-12;
    elseif(i==2); dt=2^-10;
    elseif(i==3); dt=2^-8;
    elseif(i==4); dt=2^-6;
    elseif(i==5); dt=2^-4;
    elseif(i==6); dt=2^-2;
    end
    deltamat = [sqrt(dt)            0;
          dt^1.5/2    dt^1.5/(2*sqrt(3))];
    freq = 1/dt;
    time = 0:dt:T-dt;
    N = T*freq;

for scheme = 1:3  % SCHEME 1-gEM, 2-gMilstein, 3-gTaylor 1.5


for nsim = 1:NSIM
% nsim
y = zeros(10,N);

y(:,1) = [0;0; % x
          0;-1; % xdot
          1/sqrt(3);1/sqrt(3);-1/sqrt(3);  % q
         0.5;0.2;0.3]; % omega

for n = 1:N
  n;
  if scheme == 2 ; rng(1); else;    rng(0);  end
    DWE = sigWE*(deltamat(1,:)*randn(2,4))'; 
    DZE = sigZE*(deltamat(2,:)*randn(2,4))'; 
    DWS2 = sigWS2*(deltamat(1,:)*randn(2,3))'; 
    DZS2 = sigZS2*(deltamat(2,:)*randn(2,3))'; 
    DWTS = sigWTS*(deltamat(1,:)*randn(2,1))'; 
    DZTS = sigZTS*(deltamat(2,:)*randn(2,1))'; 

% Motion of cart (Euclidean)
    aE = aE_v([y(:,n)]);
    bE = bEf;
    L0aE = L0aE_v([y(:,n)]);
    L1aE = L1aE_v([y(:,n)]);
    L0bE = L0bE_v([y(:,n)]);
    L1bE = L1bE_v([y(:,n)]);
    L1L1bE = L1L1bE_v([y(:,n)]);

    if scheme == 1
    y(1:4,n+1) = y(1:4,n) + aE.*dt + bE.*DWE;
    elseif scheme == 2
    y(1:4,n+1) = y(1:4,n) + aE.*dt + bE.*DWE+L1bE.*(DWE.^2-dt)/2;
    elseif scheme == 3
    y(1:4,n+1) = y(1:4,n) + aE.*dt + bE.*DWE...
                      + L0aE.*dt^2/2 + L1bE.*(DWE.^2-dt)/2 + L1aE.*DZE...
                      + L0bE.*(DWE*dt - DZE) + L1L1bE.*((1/3)*DWE - dt).*DWE;
    end

% Position vector of pendulum (S2)
vars = [y(1:4,n+1);y(5:end,n)];
    aS2 = aS2_v(vars);
    bS2 = bS2f;
    L0aS2 = L0aS2_v([vars]);
    L1aS2 = L1aS2_v([vars]);
    L0bS2 = L0bS2_v([vars]);
    L1bS2 = L1bS2_v([vars]);
    L1L1bS2 = L1L1bS2_v([vars]);

    if scheme == 1              
    OMEG =  aS2.*dt + bS2.*DWS2;
    elseif scheme == 2              
    OMEG =  aS2.*dt + bS2.*DWS2 + L1bS2.*(DWS2.^2-dt)/2;
    elseif scheme == 3
    OMEG =  aS2.*dt + bS2.*DWS2...
                  + L0aS2.*dt^2/2 + L1bS2.*(DWS2.^2-dt)/2 + L1aS2.*DZS2...
                  + L0bS2.*(DWS2*dt - DZS2) + L1L1bS2.*((1/3)*DWS2 - dt).*DWS2;

    end
    y(5:7,n+1) = so3_exp_new(OMEG)*y(5:7,n);   

% Angular momentum of pendulum (TS2)
vars = [y(1:7,n+1);y(8:end,n)];
    aTS = aTS_v([vars]);
    bTS = bTS_v([vars]);
    L0aTS = L0aTS_v([vars]);
    L1aTS = L1aTS_v([vars]);
    L0bTS = L0bTS_v([vars]);
    L1bTS = L1bTS_v([vars]);
    L1L1bTS = L1L1bTS_v([vars]);

    if scheme == 1              
        omg_upd = y(8:10,n) + so3_vee(aTS.*dt + bTS.*DWTS);
        y(8:10,n+1) = ParTransport(y(1:3,n),y(1:3,n+1))*omg_upd;
    elseif scheme == 2              
        omg_upd = y(8:10,n) + so3_vee(aTS.*dt + bTS.*DWTS + L1bTS.*(DWTS.^2-dt)/2);
        y(8:10,n+1) = ParTransport(y(1:3,n),y(1:3,n+1))*omg_upd;
    elseif scheme == 3
     omg_upd = y(8:10,n) + so3_vee(aTS.*dt + bTS.*DWTS...
                      + L0aTS.*dt^2/2 + L1bTS.*(DWTS.^2-dt)/2 + L1aTS.*DZTS...
                      + L0bTS.*(DWTS*dt - DZTS)  + L1L1bTS.*((1/3)*DWTS - dt).*DWTS);
        y(8:10,n+1) = ParTransport(y(1:3,n),y(1:3,n+1))*omg_upd;
    end

end
YYc(:,:,nsim) = y(1:2,:);
clear y
end
% Taking ensemble of the position of cart
        if scheme == 1
            Yc_GEM = mean(YYc,3);
        elseif scheme == 2
            Yc_Gmil = mean(YYc,3);
       elseif scheme == 3
            Yc_GTay = mean(YYc,3);
        end
clear YYc  

end
maxEMc(:,i) = max(Yc_GEM')';
maxmilc(:,i) = max(Yc_Gmil')';
maxTayc(:,i) = max(Yc_GTay')';

errEMc(i) = log2(norm(maxEMc(:,i) - maxEMc(:,1)));
errmilc(i) = log2(norm(maxmilc(:,i) - maxEMc(:,1)));
errTayc(i) = log2(norm(maxTayc(:,i) - maxEMc(:,1)));
xdt(i)=log2(dt);  % logarithm of time step wrt the base '2'
end
% Plotting 
figure; sgtitle('Figure 10(a)')
plot(xdt(3:end), errEMc(3:end),'-or');hold on; 
plot(xdt(3:end), errmilc(3:end),'-ob');hold on; 
plot(xdt(3:end), errTayc(3:end),'-ok')
ylabel('log_2(||E[q_{ref}] - E[q]||)'); xlabel('log_2(\Deltat)')
legend('gEM','gMilstein','gTaylor 1.5')
set(gca,'fontname','times new roman','fontsize',24,'fontweight','bold')

